import os
import platform
import random
import time
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from fake_useragent import FakeUserAgent
from .utility import *  # Certifique-se de importar a classe Utility corretamente

# Configuração de logging
logger = logging.getLogger('BrowserHandler')
logger.setLevel(logging.INFO)

class BrowserHandler:
    def __init__(self, site, profile, proxy, profile_folder):
        self.profile = profile
        self.proxy = proxy
        self.site = site
        self.utility = Utility()
        self.driver = None
        self.ua = FakeUserAgent()
        self.user_agent = self.ua.random
        self.profile_folder = profile_folder

    def _random_sleep(self, min_seconds=5, max_seconds=10):
        """Pause the execution for a random time."""
        sleep_time = random.uniform(min_seconds, max_seconds)
        logger.info(f"Sleeping for {sleep_time:.2f} seconds.")
        time.sleep(sleep_time)

    def _initialize_webdriver_options(self):
        """Initialize Chrome options for WebDriver."""
        chrome_options = Options()
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--enable-file-cookies")
        chrome_options.add_argument(f"user-agent={self.user_agent}")
        chrome_options.add_argument(f"--user-data-dir={self.profile_folder+self.profile}")
        chrome_options.add_argument("--disable-infobars")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument("--verbose")
        chrome_options.add_argument("--log-path=chromedriver.log")
        return chrome_options

    def initialize_driver(self):
        """Initialize the Selenium WebDriver."""
        try:
            chrome_options = self._initialize_webdriver_options()
            os_type = platform.system()
            if os_type == "Windows":
                chrome_binary_path = os.path.join(os.getcwd(), "c:\\chrome-win64\\chrome.exe")
                chrome_driver_path = os.path.join(os.getcwd(), "c:\\chrome-win64\\chromedriver.exe")
                self.service = ChromeService(executable_path=chrome_driver_path, enable_verbose_logging = True)
                chrome_options.binary_location = chrome_binary_path   
            elif os_type == "Linux":
                chrome_binary_path = "/usr/bin/google-chrome-stable"
                chrome_driver_path = "./chromedriver"
                chrome_options.add_argument('--headless')
                self.service = ChromeService(ChromeDriverManager().install())
            else:
                raise Exception("Unsupported operating system.")
            
            self.driver = webdriver.Chrome(service=self.service, options=chrome_options)
        except Exception as e:
            logger.error(f"Exception occurred while initializing driver: {e}")
            self.utility.print_exception()
            raise

    def validate_bot(self):
        """Validate if the bot is detected by the site."""
        if not self.driver:
            logger.error("Driver not initialized.")
            raise Exception("Driver not initialized.")
        try:
            self.driver.execute_script("window.open('', '_blank');")
            self.driver.switch_to.window(self.driver.window_handles[-1])
            self.driver.get("https://www.google.com")
            search_box = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.NAME, "q"))
            )
            search_box.send_keys(self.site)
            search_box.send_keys(Keys.RETURN)
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "h3"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "h3").click()
            self._random_sleep(5, 10)
            if self.driver.find_elements(By.XPATH, '//*[@id="challenge-stage"]'):
                logging.warning(f"Bot detected on site: {self.site}")
                return False
            return True
        except Exception as e:
            logger.error(f"Exception occurred during bot validation: {e}")
            self.utility.print_exception()
            raise

    def execute(self):
        """Execute the main operation."""
        try:
            self.initialize_driver()
            if(self.validate_bot()):
                return self.driver
            
        except Exception as e:
            logger.error(f"Exception occurred during execution: {e}")
            self.utility.print_exception()
            raise
